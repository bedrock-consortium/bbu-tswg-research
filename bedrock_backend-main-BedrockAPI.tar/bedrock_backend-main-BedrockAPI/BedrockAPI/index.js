const express = require('express');
const app = express();
const axios = require('axios');
const { response } = require('express');
var fs = require("fs");
var cors = require('cors');
app.use(express.json());

app.use(cors()); // Use this after the variable declaration

var healthcreds = {}

//READ Request Handlers
app.get('/', (req, res) => {
    res.send('Welcome to the Bedrock API!!!');
});

app.get('/healthcreds', (req,res)=> {

    axios.get('http://167.24.233.23:9893/credentials')
    .then(response => {
      //console.log(`statusCode: ${response.statusText}`)
      console.log('statusCodeText: ', response.status)
      console.log('testvalue: ', response.data.results[0].attrs)
      healthcreds['tobacco']=response.data.results[0].attrs.tobacco
      healthcreds['name']=response.data.results[1].attrs.firstname + " " + response.data.results[1].attrs.lastname
      //healthcreds['dob']=response.data.results[1].attrs.dob
      healthcreds['dob']='10/10/1976'
      healthcreds['birthgender']=response.data.results[1].attrs.sex
      healthcreds['state']=response.data.results[1].attrs.state
      healthcreds['militarystatus']='Active'
      healthcreds['height']='5ft 6in'
      healthcreds['weight']='155 lbs'
      console.log('creds: ', healthcreds)
      res.send(healthcreds);
      //res.send(response.data.results[0].attrs);
    })
    .catch(error => {
      console.error(error)
    })

  console.log();

});

app.get('/healthcredsraw', (req,res)=> {
    const axios = require('axios');

    axios.get('http://167.24.233.23:9893/credentials')
      .then(response => {
        console.log();
        res.send(response.data.results);
      })
      .catch(error => {
        console.error(error)
      })

});

//PORT ENVIRONMENT VARIABLE
const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Listening on port ${port}..`));