import React from 'react';
import {BrowserRouter, Route} from 'react-router-dom';

import Header from './components/Header';
import Login from './components/Login';
import MainPage from './components/MainPage';
import FormPage from './components/QR Input/FormPage';
import Validating from './components/Validating';
import FormPageManually from './components/Manual Input/FormPageMan';
import CoveragePage from './components/CoveragePage';
import QuotesPage from './components/QuotesPage';
import AboutYouPage from './components/AboutYouPage';
import ContactInformationPage from './components/ContactInformationPage';
import PolicyOptionsPage from './components/PolicyOptionsPage';
import ExistingPoliciesOrContractsPage from './components/ExistingPoliciesOrContractsPage';
import BeneficiariesPage from './components/BeneficiariesPage';
import VerifyPage from './components/VerifyPage';
import BasicTable from './components/Table Structure/BasicTable';

const App = () => {
  return(
    <div>
      <BrowserRouter>
        <Header>Header</Header>
        <Route path='/' exact component={MainPage} />
        <Route path='/login' exact component={Login} />
        <Route path='/validating' exact component={Validating} />
        <Route path='/form-page' exact component={FormPage} />
        <Route path='/form-page-manually' exact component={FormPageManually} />
        <Route path='/coverage-page' exact component={CoveragePage} />
        <Route path='/quotes-page' exact component={QuotesPage} />
        <Route path='/about-you-page' exact component={AboutYouPage} />
        <Route path='/contact-information-page' exact component={ContactInformationPage} />
        <Route path='/policy-options-page' exact component={PolicyOptionsPage} />
        <Route path='./existing-policies-or-contracts-page' exact component={ExistingPoliciesOrContractsPage} />
        <Route path='/beneficiaries-page' exact component={BeneficiariesPage} />
        <Route path='/verify-page' exact component={VerifyPage} />
        <Route path='/basic-table' exact component={BasicTable} />
      </BrowserRouter>
    </div>
  );
};



export default App;
