import React from 'react';
import {Link} from 'react-router-dom';

import '../css/header.css'
import usaaLogo from '../images/USAA-Logo.jpg';

const Header = () => {
    return(
        <h1 className='header'>
            <Link to='/'>
                <img className='header-image' src={usaaLogo} alt='USAA logo'/>
            </Link>
        </h1>
    );
};

export default Header;