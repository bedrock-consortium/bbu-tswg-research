import React from "react";
import { Link } from "react-router-dom";

import "../css/login.css";

const Login = () => {
  return (
    <div className="login">
      <Link to="/form-page">Use Digital Credentials</Link>
      <p className="text-edit">or</p>

      <p>
        <Link to="/form-page-manually">Enter Information Manually</Link>
      </p>
    </div>
  );
};

export default Login;
