import React from 'react';

import {Link} from "react-router-dom";

import contactInformationImage from '../images/contact-information.png'

import "../css/coveragePage.css";

const ContactInformationPage = () => {
    return (
        <Link to="policy-options-page">
            <img className='coverage' src={contactInformationImage} alt='Contact Information Page' />
        </Link>
    );

};

export default ContactInformationPage;