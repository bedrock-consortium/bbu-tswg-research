import React, { useMemo } from "react";
import { useTable } from "react-table";
import MOCK_DATA from "./MOCK_DATA.json";
import { COLUMNS } from "./columns";
import {Link} from 'react-router-dom';

import "../../css/aboutYouPage.css";

const BasicTable = () => {
  fetch("./MOCK_DATA.json", { mode: "no-cors" }).then((res) => res.json);
  // .then((data) => console.log(data));

  const columns = useMemo(() => COLUMNS, []);
  const data = useMemo(() => MOCK_DATA, []);

  const tableInstance = useTable({
    columns: columns,
    data: data,
  });

  const { getTableProps, getTableBodyProps } = tableInstance;
  // console.log("columnsss", data);

  return (
    <table {...getTableProps( data)}>
      <tbody {...getTableBodyProps()}>
        <tr>
          <th className="thead">Name</th>
          <div className="row">{data[0].full_name}</div>
        </tr>
        <tr>
          <th className="thead">Military Status</th>
          <div className="row">{data[0].military_status}</div>
        </tr>
        <tr>
          <th className="thead">Occupation</th>
          <div className="row">{data[0].occupation}</div>
        </tr>
        <tr>
          <th className="thead">Industry</th>
          <div className="row">{data[0].industry}</div>
        </tr>
        <tr>
          <th className="thead">Annual Income</th>
          <div className="row">{data[0].annual_income}</div>
        </tr>
        <tr>
          <th className="thead">Citizenship</th>
          <div className="row">{data[0].citizenship}</div>
        </tr>
        <tr>
          <th className="thead">Date of Birth</th>
          <div className="row">{data[0].dob}</div>
        </tr>
        <tr>
          <th className="thead">State</th>
          <div className="row">{data[0].state}</div>
        </tr>
        <tr>
          <th className="thead">Driver's License</th>
          <div className="row">{data[0].drivers_license}</div>
        </tr>
        <tr>
          <th className="thead">License Number</th>
          <div className="row">{data[0].license_number}</div>
        </tr>
        <tr>
          <th className="thead">State Issued</th>
          <div className="row">{data[0].state_issued}</div>
        </tr>
      </tbody>
      {/* <Link to="login">
        <button type="button">Apply For Life Insurance</button>
      </Link> */}
    </table>
  );
};

export default BasicTable;
