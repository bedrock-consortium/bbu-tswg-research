export const COLUMNS = [
    {
        Header: 'Name',
        accessor: 'full_name'
    },{
        Header: 'Military Status',
        accessor: 'military_status'
    },
    {
        Header: 'Occupation',
        accessor: 'occupation'
   }, {
        Header: 'Industry',
        accessor: 'industry'
    }, {
        Header: 'Annual Income',
        accessor: 'annual_income'
    }, {
        Header: 'U.S. Citizen',
        accessor: 'citizenship'
    }, {
        Header: 'Date of Birth',
        accessor:'dob'
    }, {
        Header: 'State of Birth',
        accessor:'state'
    }, {
        Header: 'Drivers License',
        accessor: 'drivers_license'
    }, {
        Header: 'License Number',
        accessor: 'license_number'
    }, {
        Header: 'State of Issue',
        accessor: 'state_issued'
    }
]