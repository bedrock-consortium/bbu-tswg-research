import React from "react";

import { Link } from "react-router-dom";

import "../css/coveragePage.css";
import coverageImage from "../images/coverage.png";

const CoveragePage = () => {
  return (
    <div className="main">
        <input className='yearly-income' type='text' />
        <input className='mortgage' type='text' />
        <input className='debt' type='text' />
        <input className='saved' type='text' />
        <input className='life-insurance' type='text' />
        <div className="button-positioning">
            
            <Link to="/quotes-page">
                <button className="new-button">Next</button>
            </Link>
          
        </div>
        <img className="coverage" src={coverageImage} alt="Coverage Page" />
    </div>
  );
};

export default CoveragePage;
