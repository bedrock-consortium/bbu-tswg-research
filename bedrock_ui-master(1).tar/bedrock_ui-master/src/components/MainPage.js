import React from 'react';
import {Link} from 'react-router-dom';

import '../css/mainPage.css'
const MainPage = () => {
    return(
        <div className="main-page-button">
            <Link to='login'>
                <button className="button-test">
                Apply For Life Insurance
                </button>
            </Link>
        </div>
    );
};

export default MainPage;