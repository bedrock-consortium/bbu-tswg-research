import React, { useState } from "react";
import DatePicker from "react-datepicker";
import { Link } from "react-router-dom";

import State from './State'
import Questions from "./Questions";
import Status from "./MilitaryStatus";

import "../../css/formPage.css";


function FormPageManually() {
  const renderDatePicker = ({ input: { onChange, value }, showTime }) => (
    <DatePicker
      onChange={onChange}
      format="DD MM YYY"
      time={showTime}
      value={!value ? null : new Date(value)}
    />
  );
  const [input, setInput] = useState();
  const handleInput = (event) => {
    event.preventDefault();
    setInput(event.target.value);
  };
  return (
    <div>
      <div className="given">
        <form className="form">
          <div>
            <span>
              <h2>Personal Info</h2>
              <p>
                This information helps us understand a bit about you and the
                status of your health so that we can estimate your rate.
              </p>
            </span>
            <span className="member-info">
              <label>Member Information: </label>
              <input type="text" onChange={handleInput} />
            </span>
            <span className="DOB">
              <label>Date of Birth: </label>
              <input type="text" component={renderDatePicker} />
            </span>
            <span className="gender">
              <label>Birth Gender: </label>
              <select>
                <option value="empty"> </option>
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </span>
            <span className="height">
              <label>Height: </label>
              <span>
                <input type="text" onChange={handleInput} />
                <label> feet</label>
                <input type="text" onChange={handleInput} />
                <label> inches</label>
              </span>
            </span>
            <span className="weight">
              <label>Weight(lbs): </label>
              <input type="text" onChange={handleInput} />
            </span>
            <State/>
            <Status/>
          </div>
          <Questions/>
          
        </form>
      </div>
      <div>
          <Link to="/coverage-page">
            <button>Next</button>
          </Link>
        </div>
    </div>
  );
}

export default FormPageManually;
