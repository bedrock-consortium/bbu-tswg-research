import React from "react";

export default function Status() {
  return (
    <span className="militaryStatus">
      <label>Military Status: </label>
      <select>
          <option> </option>
          <option>None </option>
          <option>Active </option>
          <option>Reserve </option>
          <option>National Guard </option>
          <option>Retired </option>
          <option>Separated </option>
      </select>
    </span>
  );
}
