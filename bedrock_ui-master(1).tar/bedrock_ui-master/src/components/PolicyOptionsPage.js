import React from 'react';

import {Link} from "react-router-dom";

import policyOptionsImage from '../images/policy-options.png'

import "../css/coveragePage.css";

const PolicyOptionsPage = () => {
    return (
        <Link to="/existing-policies-or-contracts-page">
            <img className='coverage' src={policyOptionsImage} alt='Policy Options Page' />
        </Link>
    );
};

export default PolicyOptionsPage;