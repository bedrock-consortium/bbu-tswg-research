import React from 'react';

import {Link} from "react-router-dom";

import verifyImage from '../images/verify.png'

import "../css/coveragePage.css";

const VerifyPage = () => {
    return(
        <Link to="contact-information-page">
            <img className='coverage' src={verifyImage} alt='Verify Page' />
        </Link>
        
    );
};

export default VerifyPage;