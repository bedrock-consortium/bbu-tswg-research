import React from 'react';

import {Link} from "react-router-dom";

import existingPoliciesOrContractsImage from '../images/existing-policies-or-contracts.png';

import "../css/coveragePage.css";


const ExistingPoliciesOrContractsPage = () => {
    return(
        <Link to="beneficiaries-page">
            <img className='coverage' src={existingPoliciesOrContractsImage} alt='Existing Policies Or Contracts Page' />
        </Link>
    );
};


export default ExistingPoliciesOrContractsPage;