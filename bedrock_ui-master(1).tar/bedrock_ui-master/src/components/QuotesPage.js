import React from 'react';

import { Link } from "react-router-dom";

import "../css/quotesPage.css";
import quotesImage from '../images/quotes.png';

// import { ImageBackground, StyleSheet, Text, View } from "react-native";

const QuotesPage = () => {
    return(
        
        <Link to="about-you-page">
            <img className='coverage' src={quotesImage} alt='Quotes Page' />
        </Link>
        

    );
};


export default QuotesPage;