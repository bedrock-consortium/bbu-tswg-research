import React from 'react';

const Validating = () => {
    return(
        <div>
            Validating digital identity credentials
        </div>
    );
};

export default Validating;