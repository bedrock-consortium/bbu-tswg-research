import React from "react";

import "../../css/formPage.css";

export default function Questions() {
  return (
    <div className="form-text-edit">
      {/* <span className="question1">
        <label>
          Have you used nicotine, tobacco, or a tobacco substitute in the last
          12 months?{" "}
        </label>
        <select>
          <option className="empty"> </option>
          <option className="yes">Yes</option>
          <option className="no">No</option>
        </select>
      </span> */}
      <span className="question2">
        <label>
          Does your medical history include a condition that has requires a
          doctor's care, such as cancer, depression, or sleep apnea?{" "}
        </label>
        <select>
          <option className="empty"> </option>
          <option className="yes">Yes</option>
          <option className="no">No</option>
        </select>
      </span>
      <span className="question3">
        <label>
          Did your birth mother or birth father die of a cardiovascular disease
          or cancer before the age of 60?{" "}
        </label>
        <select>
          <option className="empty"> </option>
          <option className="yes">Yes</option>
          <option className="no">No</option>
        </select>
      </span>
    </div>
  );
}
