import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import Questions from "./Questions";
import GivenInfo from "./GivenInfo";

import "../../css/formPage.css";
import "../../css/mainPage.css";

function FormPage() {
  return (
    <div>
      <div className="given">
        <form className="form">
          <GivenInfo />
          <Questions />
          <div className="positioning-of-button">
            <Link to="/coverage-page">
              <button className="button-test">Next</button>
            </Link>
        </div>
        </form>
        
      </div>
      
    </div>
  );
}

export default FormPage;
