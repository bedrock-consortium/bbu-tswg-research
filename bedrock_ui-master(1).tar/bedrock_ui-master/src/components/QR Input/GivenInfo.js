import React, { useEffect, useState } from "react";
import axios from "axios";

import "../../css/formPage.css";

export default function GivenInfo() {
  const [input, setInput] = useState({});
  const handleInput = (event) => {
    event.preventDefault();
    setInput(event.target.value);
  };

  useEffect(() => {
    axios.get("http://localhost:8080/healthcreds").then((res) => {
      setInput(res.data);
    });
  }, []);

  return (
    <div>
      <span>
        <h2>Personal Info</h2>
        <p className="form-text-edit">
          This information helps us understand a bit about you and the status of
          your health so that we can estimate your rate.
        </p>
      </span>
      <span className="member-info">
        <label>Member Name: {input.name} </label>
      </span>
      <span className="DOB">
        <label>Date of Birth: {input.dob} </label>
      </span>
      <span className="gender">
        <label>Birth Gender: {input.birthgender}</label>
      </span>
      <span className="height">
        <label>Height: {input.height}</label>
      </span>
      <span className="weight">
        <label>Weight(lbs): {input.weight} </label>
      </span>
      <span className="state">
        <label>State: {input.state} </label>
      </span>
      <span className="militaryStatus">
        <label>Military Status: {input.militarystatus} </label>
      </span>
      <span className="question1">
        <label>
          Have you used nicotine, tobacco, or a tobacco substitute in the last
          12 months?{" "}
        </label>
        <select>
          {/* <option className="empty"> </option>
          <option className="yes">Yes</option> */}
          <option className="no">{input.tobacco}</option>
        </select>
      </span>
    </div>
  );
}
