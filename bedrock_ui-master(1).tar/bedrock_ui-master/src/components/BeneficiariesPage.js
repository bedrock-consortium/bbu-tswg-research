import React from 'react';

import {Link} from "react-router-dom";

import beneficiariesImage from '../images/beneficiaries.png';

import "../css/coveragePage.css";

const BeneficiariesPage = () => {
    return(
        <Link to="/verify-page">
            <img className='coverage' src={beneficiariesImage} alt='Beneficiaries Page' />
        </Link>
    );
};

export default BeneficiariesPage;