import React from "react";
import BasicTable from "./Table Structure/BasicTable";



function AboutYouPage() {
  return (
   <BasicTable/>
  );
}

export default AboutYouPage;
