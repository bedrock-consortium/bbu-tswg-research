# Bedrock_Backend

backend code for Bedrock POC