const express = require('express');
const app = express();
var fs = require("fs");
app.use(express.json());
 
const healthcreds = [
{
    name: 'jane doe', dob: '12/12/80', birthgender: 'Female', state: 'New York', militarystatus: 'single', height: '5 ft 6 in', weight: '155 lbs'}
]

//READ Request Handlers
app.get('/', (req, res) => {
    res.send('Welcome to the Bedrock API!!!');
});

app.get('/healthcreds', (req,res)=> {
    res.send(healthcreds);
});

//PORT ENVIRONMENT VARIABLE
const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Listening on port ${port}..`));